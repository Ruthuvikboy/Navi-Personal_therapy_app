import React from 'react';
import { StyleSheet, ScrollView, View, Text, SafeAreaView, StatusBar } from 'react-native';
import WelcomeCard from '@/components/Home/WelcomeCard';
import QuickActions from '@/components/Home/QuickActions';
import Card from '@/components/ui/Card';
import JournalEntry from '@/components/Journal/JournalEntry';
import { ChartBar as BarChart2, Sparkles } from 'lucide-react-native';

export default function HomeScreen() {
  // Mock data
  const recentJournal = {
    date: '2025-05-11',
    title: 'Feeling accomplished today',
    snippet: 'I managed to finish my science project ahead of schedule. It was challenging, but I feel proud of what I accomplished.',
    mood: '😊 Good',
  };

  const dailyAffirmation = "I am capable of handling whatever challenges come my way today.";

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#FFFFFF" />
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.content}>
          <WelcomeCard username="Alex" />
          
          <QuickActions />
          
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <BarChart2 size={20} color="#4A90E2" />
              <Text style={styles.sectionTitle}>Latest Mood</Text>
            </View>
            <Card variant="outlined" style={styles.moodCard}>
              <Text style={styles.moodDate}>Today, 2:30 PM</Text>
              <View style={styles.moodContent}>
                <Text style={styles.moodEmoji}>😊</Text>
                <View style={styles.moodTextContainer}>
                  <Text style={styles.moodLabel}>Good</Text>
                  <Text style={styles.moodDescription}>
                    Feeling pretty good today. School was less stressful than expected.
                  </Text>
                </View>
              </View>
            </Card>
          </View>
          
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <Sparkles size={20} color="#9C6ADE" />
              <Text style={styles.sectionTitle}>Daily Affirmation</Text>
            </View>
            <Card variant="elevated" style={styles.affirmationCard}>
              <Text style={styles.affirmationText}>"{dailyAffirmation}"</Text>
            </Card>
          </View>
          
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Recent Journal</Text>
            <JournalEntry 
              date={recentJournal.date}
              title={recentJournal.title}
              snippet={recentJournal.snippet}
              mood={recentJournal.mood}
            />
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  content: {
    padding: 16,
  },
  section: {
    marginVertical: 12,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
    paddingHorizontal: 8,
  },
  sectionTitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 18,
    color: '#333333',
    marginLeft: 8,
  },
  moodCard: {
    padding: 16,
  },
  moodDate: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
    color: '#6B7280',
    marginBottom: 8,
  },
  moodContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  moodEmoji: {
    fontSize: 40,
    marginRight: 16,
  },
  moodTextContainer: {
    flex: 1,
  },
  moodLabel: {
    fontFamily: 'Inter-Medium',
    fontSize: 16,
    color: '#333333',
    marginBottom: 4,
  },
  moodDescription: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#4B5563',
    lineHeight: 20,
  },
  affirmationCard: {
    backgroundColor: '#9C6ADE',
    padding: 20,
  },
  affirmationText: {
    fontFamily: 'Inter-Medium',
    fontSize: 18,
    color: '#FFFFFF',
    textAlign: 'center',
    lineHeight: 24,
  },
});