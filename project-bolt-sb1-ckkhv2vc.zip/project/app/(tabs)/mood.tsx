import React, { useState } from 'react';
import { StyleSheet, ScrollView, View, Text, SafeAreaView, StatusBar, TextInput } from 'react-native';
import MoodSelector from '@/components/MoodTracker/MoodSelector';
import MoodCalendar from '@/components/MoodTracker/MoodCalendar';
import Button from '@/components/ui/Button';
import Card from '@/components/ui/Card';

type Mood = 'great' | 'good' | 'okay' | 'sad' | 'awful';

interface MoodEntry {
  date: string;
  mood: Mood;
  note?: string;
}

export default function MoodScreen() {
  // State for current mood selection
  const [selectedMood, setSelectedMood] = useState<Mood | null>(null);
  const [note, setNote] = useState('');
  
  // Mock data for mood entries
  const [moodEntries, setMoodEntries] = useState<MoodEntry[]>([
    { date: '2025-05-10', mood: 'great', note: 'Had a great day at the park!' },
    { date: '2025-05-09', mood: 'good', note: 'School was fun today.' },
    { date: '2025-05-08', mood: 'okay', note: 'Nothing special happened.' },
    { date: '2025-05-07', mood: 'sad', note: 'Got a bad grade on my test.' },
    { date: '2025-05-06', mood: 'good', note: 'Hung out with friends.' },
    { date: '2025-05-05', mood: 'great', note: 'Birthday party was amazing!' },
  ]);

  const handleSubmit = () => {
    if (selectedMood) {
      const newEntry: MoodEntry = {
        date: new Date().toISOString().split('T')[0],
        mood: selectedMood,
        note: note.trim() || undefined,
      };
      
      setMoodEntries([newEntry, ...moodEntries]);
      setSelectedMood(null);
      setNote('');
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#FFFFFF" />
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.content}>
          <Text style={styles.pageTitle}>Mood Tracker</Text>
          
          <Card variant="outlined" style={styles.checkInCard}>
            <Text style={styles.checkInTitle}>Daily Mood Check-In</Text>
            <MoodSelector 
              selectedMood={selectedMood}
              onSelectMood={setSelectedMood}
            />
            
            <Text style={styles.noteLabel}>Add a note (optional):</Text>
            <TextInput
              style={styles.noteInput}
              value={note}
              onChangeText={setNote}
              placeholder="How are you feeling today?"
              multiline
              numberOfLines={3}
              maxLength={200}
            />
            
            <Button 
              title="Save Mood" 
              onPress={handleSubmit}
              disabled={!selectedMood}
              fullWidth
              style={styles.submitButton}
            />
          </Card>
          
          <View style={styles.historySection}>
            <Text style={styles.sectionTitle}>Your Mood History</Text>
            <MoodCalendar 
              entries={moodEntries}
              month="May 2025"
            />
            
            <Text style={styles.entriesTitle}>Recent Entries</Text>
            {moodEntries.slice(0, 3).map((entry, index) => (
              <Card key={index} variant="outlined" style={styles.entryCard}>
                <View style={styles.entryHeader}>
                  <Text style={styles.entryDate}>
                    {new Date(entry.date).toLocaleDateString('en-US', {
                      weekday: 'short',
                      month: 'short',
                      day: 'numeric',
                    })}
                  </Text>
                  <View style={[
                    styles.moodTag,
                    getMoodTagStyle(entry.mood)
                  ]}>
                    <Text style={styles.moodTagText}>{getMoodEmoji(entry.mood)} {capitalize(entry.mood)}</Text>
                  </View>
                </View>
                {entry.note && <Text style={styles.entryNote}>{entry.note}</Text>}
              </Card>
            ))}
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

// Helper functions
function getMoodEmoji(mood: Mood): string {
  switch (mood) {
    case 'great': return '😄';
    case 'good': return '🙂';
    case 'okay': return '😐';
    case 'sad': return '😔';
    case 'awful': return '😢';
  }
}

function capitalize(str: string): string {
  return str.charAt(0).toUpperCase() + str.slice(1);
}

function getMoodTagStyle(mood: Mood) {
  switch (mood) {
    case 'great': return styles.greatMood;
    case 'good': return styles.goodMood;
    case 'okay': return styles.okayMood;
    case 'sad': return styles.sadMood;
    case 'awful': return styles.awfulMood;
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  content: {
    padding: 16,
  },
  pageTitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 24,
    color: '#333333',
    marginBottom: 16,
    marginTop: 8,
  },
  checkInCard: {
    padding: 16,
    marginBottom: 24,
  },
  checkInTitle: {
    fontFamily: 'Inter-Medium',
    fontSize: 18,
    color: '#333333',
    marginBottom: 16,
    textAlign: 'center',
  },
  noteLabel: {
    fontFamily: 'Inter-Medium',
    fontSize: 14,
    color: '#4B5563',
    marginBottom: 8,
    marginTop: 16,
  },
  noteInput: {
    borderWidth: 1,
    borderColor: '#E5E7EB',
    borderRadius: 8,
    padding: 12,
    fontSize: 14,
    minHeight: 80,
    fontFamily: 'Inter-Regular',
    color: '#4B5563',
    backgroundColor: '#F9FAFB',
    marginBottom: 16,
  },
  submitButton: {
    marginTop: 8,
  },
  historySection: {
    marginTop: 16,
  },
  sectionTitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 20,
    color: '#333333',
    marginBottom: 12,
  },
  entriesTitle: {
    fontFamily: 'Inter-Medium',
    fontSize: 18,
    color: '#333333',
    marginTop: 24,
    marginBottom: 8,
  },
  entryCard: {
    marginVertical: 8,
    padding: 16,
  },
  entryHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  entryDate: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#6B7280',
  },
  moodTag: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
  },
  greatMood: {
    backgroundColor: 'rgba(76, 175, 80, 0.2)',
  },
  goodMood: {
    backgroundColor: 'rgba(139, 195, 74, 0.2)',
  },
  okayMood: {
    backgroundColor: 'rgba(255, 193, 7, 0.2)',
  },
  sadMood: {
    backgroundColor: 'rgba(255, 152, 0, 0.2)',
  },
  awfulMood: {
    backgroundColor: 'rgba(244, 67, 54, 0.2)',
  },
  moodTagText: {
    fontFamily: 'Inter-Medium',
    fontSize: 12,
  },
  entryNote: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#4B5563',
    lineHeight: 20,
  },
});