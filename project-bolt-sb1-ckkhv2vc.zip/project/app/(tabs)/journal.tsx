import React, { useState } from 'react';
import { 
  StyleSheet, 
  View, 
  Text, 
  SafeAreaView, 
  StatusBar, 
  TextInput,
  TouchableOpacity,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { Plus, X, Save, ArrowLeft } from 'lucide-react-native';
import JournalEntry from '@/components/Journal/JournalEntry';

interface Entry {
  id: string;
  date: string;
  title: string;
  content: string;
  mood?: string;
}

export default function JournalScreen() {
  const [entries, setEntries] = useState<Entry[]>([
    {
      id: '1',
      date: '2025-05-11',
      title: 'Feeling accomplished today',
      content: 'I managed to finish my science project ahead of schedule. It was challenging, but I feel proud of what I accomplished. My teacher seemed impressed, and that made me feel even better about my work. I hope I get a good grade!',
      mood: '😊 Good',
    },
    {
      id: '2',
      date: '2025-05-10',
      title: 'Made a new friend',
      content: 'There\'s a new student in class. Their name is Jamie and they seem really nice. We sat together at lunch and talked about our favorite music. Turns out we both like the same bands! I\'m looking forward to hanging out more.',
      mood: '😄 Great',
    },
  ]);
  
  const [isCreating, setIsCreating] = useState(false);
  const [selectedEntry, setSelectedEntry] = useState<Entry | null>(null);
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');

  const handleNewEntry = () => {
    setIsCreating(true);
    setSelectedEntry(null);
    setTitle('');
    setContent('');
  };
  
  const handleSelectEntry = (entry: Entry) => {
    setSelectedEntry(entry);
    setTitle(entry.title);
    setContent(entry.content);
    setIsCreating(true);
  };
  
  const handleSave = () => {
    if (!title.trim() || !content.trim()) return;
    
    if (selectedEntry) {
      // Update existing entry
      setEntries(entries.map(entry => 
        entry.id === selectedEntry.id 
          ? { ...entry, title, content } 
          : entry
      ));
    } else {
      // Create new entry
      const newEntry: Entry = {
        id: Date.now().toString(),
        date: new Date().toISOString().split('T')[0],
        title,
        content,
        mood: '😐 Okay', // Default mood for now
      };
      setEntries([newEntry, ...entries]);
    }
    
    setIsCreating(false);
    setSelectedEntry(null);
    setTitle('');
    setContent('');
  };
  
  const handleCancel = () => {
    setIsCreating(false);
    setSelectedEntry(null);
    setTitle('');
    setContent('');
  };

  if (isCreating) {
    return (
      <SafeAreaView style={styles.container}>
        <StatusBar barStyle="dark-content" backgroundColor="#FFFFFF" />
        <KeyboardAvoidingView
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
          style={styles.keyboardAvoidingView}
        >
          <View style={styles.editorHeader}>
            <TouchableOpacity onPress={handleCancel} style={styles.headerButton}>
              <ArrowLeft size={24} color="#333333" />
            </TouchableOpacity>
            <Text style={styles.editorTitle}>
              {selectedEntry ? 'Edit Entry' : 'New Entry'}
            </Text>
            <TouchableOpacity 
              onPress={handleSave} 
              style={styles.headerButton}
              disabled={!title.trim() || !content.trim()}
            >
              <Save size={24} color={(!title.trim() || !content.trim()) ? '#9CA3AF' : '#4A90E2'} />
            </TouchableOpacity>
          </View>
          
          <ScrollView style={styles.editorContainer}>
            <TextInput
              style={styles.titleInput}
              value={title}
              onChangeText={setTitle}
              placeholder="Title"
              placeholderTextColor="#9CA3AF"
              maxLength={50}
            />
            <TextInput
              style={styles.contentInput}
              value={content}
              onChangeText={setContent}
              placeholder="What's on your mind today?"
              placeholderTextColor="#9CA3AF"
              multiline
              textAlignVertical="top"
            />
          </ScrollView>
        </KeyboardAvoidingView>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#FFFFFF" />
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Journal</Text>
        <Text style={styles.headerSubtitle}>Your private space to reflect</Text>
      </View>
      
      <ScrollView style={styles.entriesContainer}>
        {entries.length === 0 ? (
          <View style={styles.emptyState}>
            <Text style={styles.emptyTitle}>No entries yet</Text>
            <Text style={styles.emptyText}>Start writing your thoughts to track your emotional journey.</Text>
          </View>
        ) : (
          <View style={styles.entriesList}>
            {entries.map(entry => (
              <JournalEntry
                key={entry.id}
                date={entry.date}
                title={entry.title}
                snippet={entry.content}
                mood={entry.mood}
                onPress={() => handleSelectEntry(entry)}
              />
            ))}
          </View>
        )}
      </ScrollView>
      
      <TouchableOpacity 
        style={styles.addButton}
        onPress={handleNewEntry}
        activeOpacity={0.8}
      >
        <Plus size={24} color="#FFFFFF" />
      </TouchableOpacity>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  header: {
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#F3F4F6',
  },
  headerTitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 24,
    color: '#333333',
  },
  headerSubtitle: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#6B7280',
    marginTop: 4,
  },
  entriesContainer: {
    flex: 1,
    padding: 16,
  },
  emptyState: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 100,
    padding: 16,
  },
  emptyTitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 18,
    color: '#333333',
    marginBottom: 8,
  },
  emptyText: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#6B7280',
    textAlign: 'center',
    lineHeight: 20,
  },
  entriesList: {
    paddingBottom: 80, // Space for add button
  },
  addButton: {
    position: 'absolute',
    bottom: 24,
    right: 24,
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: '#4A90E2',
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 4,
  },
  keyboardAvoidingView: {
    flex: 1,
  },
  editorHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#F3F4F6',
  },
  headerButton: {
    width: 40,
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  editorTitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 18,
    color: '#333333',
  },
  editorContainer: {
    flex: 1,
    padding: 16,
  },
  titleInput: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 20,
    color: '#333333',
    marginBottom: 16,
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  contentInput: {
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    color: '#4B5563',
    lineHeight: 24,
    flex: 1,
    minHeight: 300,
  },
});