import React from 'react';
import { StyleSheet, ScrollView, View, Text, SafeAreaView, StatusBar, TouchableOpacity, Image, Linking } from 'react-native';
import Card from '@/components/ui/Card';
import HelplineCard from '@/components/EmergencyResources/HelplineCard';
import { ExternalLink, Info } from 'lucide-react-native';

export default function ResourcesScreen() {
  const openWebsite = (url: string) => {
    Linking.canOpenURL(url).then(supported => {
      if (supported) {
        Linking.openURL(url);
      } else {
        console.log("Cannot open URL: " + url);
      }
    });
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#FFFFFF" />
      <ScrollView style={styles.content}>
        <View style={styles.header}>
          <Text style={styles.pageTitle}>Help & Resources</Text>
          <Text style={styles.pageSubtitle}>
            Access support when you need it most
          </Text>
        </View>
        
        <View style={styles.emergencySection}>
          <Text style={styles.sectionTitle}>Emergency Support</Text>
          <Text style={styles.sectionDescription}>
            If you're in crisis or need immediate support, these helplines are available 24/7:
          </Text>
          
          <HelplineCard
            title="Crisis Text Line"
            number="741741"
            description="Text HOME to 741741 from anywhere in the USA to text with a trained Crisis Counselor."
            color="#E53E3E"
          />
          
          <HelplineCard
            title="National Suicide Prevention Lifeline"
            number="988"
            description="Call or text 988 for immediate support if you're experiencing emotional distress or suicidal thoughts."
            color="#DD6B20"
          />
          
          <HelplineCard
            title="Trevor Project (LGBTQ+ Youth)"
            number="1-866-488-7386"
            description="Crisis intervention and suicide prevention services for LGBTQ+ young people under 25."
            color="#9C6ADE"
          />
        </View>
        
        <View style={styles.resourcesSection}>
          <Text style={styles.sectionTitle}>Recommended Resources</Text>
          
          <Card variant="elevated" style={styles.resourceCard}>
            <TouchableOpacity 
              style={styles.resourceLink}
              onPress={() => openWebsite('https://www.teenmentalhealth.org/')}
            >
              <View style={styles.resourceContent}>
                <Image
                  source={{ uri: 'https://images.pexels.com/photos/1194775/pexels-photo-1194775.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2' }}
                  style={styles.resourceImage}
                />
                <View style={styles.resourceTextContainer}>
                  <Text style={styles.resourceTitle}>Teen Mental Health</Text>
                  <Text style={styles.resourceDescription}>
                    Evidence-based information about teen mental health.
                  </Text>
                </View>
              </View>
              <ExternalLink size={16} color="#4A90E2" />
            </TouchableOpacity>
          </Card>
          
          <Card variant="elevated" style={styles.resourceCard}>
            <TouchableOpacity 
              style={styles.resourceLink}
              onPress={() => openWebsite('https://www.jedfoundation.org/')}
            >
              <View style={styles.resourceContent}>
                <Image
                  source={{ uri: 'https://images.pexels.com/photos/3755760/pexels-photo-3755760.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2' }}
                  style={styles.resourceImage}
                />
                <View style={styles.resourceTextContainer}>
                  <Text style={styles.resourceTitle}>JED Foundation</Text>
                  <Text style={styles.resourceDescription}>
                    Protecting emotional health and preventing suicide among teens.
                  </Text>
                </View>
              </View>
              <ExternalLink size={16} color="#4A90E2" />
            </TouchableOpacity>
          </Card>
          
          <Card variant="elevated" style={styles.resourceCard}>
            <TouchableOpacity 
              style={styles.resourceLink}
              onPress={() => openWebsite('https://ok2talk.org/')}
            >
              <View style={styles.resourceContent}>
                <Image
                  source={{ uri: 'https://images.pexels.com/photos/6942043/pexels-photo-6942043.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2' }}
                  style={styles.resourceImage}
                />
                <View style={styles.resourceTextContainer}>
                  <Text style={styles.resourceTitle}>OK2TALK</Text>
                  <Text style={styles.resourceDescription}>
                    A community where teens can share their struggles with mental health.
                  </Text>
                </View>
              </View>
              <ExternalLink size={16} color="#4A90E2" />
            </TouchableOpacity>
          </Card>
        </View>
        
        <View style={styles.disclaimerSection}>
          <View style={styles.disclaimerHeader}>
            <Info size={16} color="#6B7280" />
            <Text style={styles.disclaimerTitle}>Important Note</Text>
          </View>
          <Text style={styles.disclaimerText}>
            MindMate is not a replacement for professional mental health care. If you're experiencing a mental health emergency, please call 988 or go to your nearest emergency room.
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  content: {
    padding: 16,
  },
  header: {
    marginBottom: 24,
  },
  pageTitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 24,
    color: '#333333',
    marginBottom: 4,
  },
  pageSubtitle: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#6B7280',
  },
  emergencySection: {
    marginBottom: 32,
  },
  resourcesSection: {
    marginBottom: 32,
  },
  sectionTitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 20,
    color: '#333333',
    marginBottom: 8,
  },
  sectionDescription: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#4B5563',
    marginBottom: 16,
    lineHeight: 20,
  },
  resourceCard: {
    marginBottom: 12,
    padding: 0,
    overflow: 'hidden',
  },
  resourceLink: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
  },
  resourceContent: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  resourceImage: {
    width: 60,
    height: 60,
    borderRadius: 8,
    marginRight: 12,
  },
  resourceTextContainer: {
    flex: 1,
  },
  resourceTitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    color: '#333333',
    marginBottom: 4,
  },
  resourceDescription: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#4B5563',
    lineHeight: 20,
  },
  disclaimerSection: {
    backgroundColor: '#F3F4F6',
    padding: 16,
    borderRadius: 12,
    marginBottom: 24,
  },
  disclaimerHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  disclaimerTitle: {
    fontFamily: 'Inter-Medium',
    fontSize: 16,
    color: '#4B5563',
    marginLeft: 8,
  },
  disclaimerText: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#4B5563',
    lineHeight: 20,
  },
});