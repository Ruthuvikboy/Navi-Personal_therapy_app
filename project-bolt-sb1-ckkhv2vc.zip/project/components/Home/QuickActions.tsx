import React from 'react';
import { StyleSheet, View, Text, TouchableOpacity } from 'react-native';
import { Heart, ChartBar as BarChart2, MessageCircle, BookOpen } from 'lucide-react-native';
import { useRouter } from 'expo-router';

interface QuickActionProps {
  label: string;
  icon: React.ReactNode;
  color: string;
  destination: string;
  onPress?: () => void;
}

function QuickAction({ label, icon, color, destination, onPress }: QuickActionProps) {
  const router = useRouter();

  const handlePress = () => {
    if (onPress) {
      onPress();
    } else {
      router.push(destination);
    }
  };

  return (
    <TouchableOpacity
      style={[styles.actionButton, { backgroundColor: color }]}
      onPress={handlePress}
      activeOpacity={0.8}
    >
      {icon}
      <Text style={styles.actionLabel}>{label}</Text>
    </TouchableOpacity>
  );
}

export default function QuickActions() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Quick Actions</Text>
      <View style={styles.actionsRow}>
        <QuickAction
          label="Check In"
          icon={<Heart size={24} color="#FFFFFF" />}
          color="#F87171"
          destination="/mood"
        />
        <QuickAction
          label="Mood"
          icon={<BarChart2 size={24} color="#FFFFFF" />}
          color="#60A5FA"
          destination="/mood"
        />
        <QuickAction
          label="Journal"
          icon={<BookOpen size={24} color="#FFFFFF" />}
          color="#34D399"
          destination="/journal"
        />
        <QuickAction
          label="Chat"
          icon={<MessageCircle size={24} color="#FFFFFF" />}
          color="#A78BFA"
          destination="/chat"
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginVertical: 16,
  },
  title: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 18,
    marginBottom: 12,
    color: '#333333',
    paddingHorizontal: 8,
  },
  actionsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  actionButton: {
    width: 72,
    height: 72,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 8,
  },
  actionLabel: {
    fontFamily: 'Inter-Medium',
    fontSize: 12,
    color: '#FFFFFF',
    marginTop: 4,
    textAlign: 'center',
  },
});