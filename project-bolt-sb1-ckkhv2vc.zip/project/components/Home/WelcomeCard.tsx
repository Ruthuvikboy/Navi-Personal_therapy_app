import React from 'react';
import { StyleSheet, View, Text, Image } from 'react-native';
import Card from '../ui/Card';

interface WelcomeCardProps {
  username: string;
  greeting?: string;
}

export default function WelcomeCard({
  username,
  greeting = 'How are you feeling today?',
}: WelcomeCardProps) {
  // Get time of day greeting
  const getTimeOfDay = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 18) return 'Good afternoon';
    return 'Good evening';
  };

  return (
    <Card variant="elevated" style={styles.container}>
      <View style={styles.content}>
        <View style={styles.textContainer}>
          <Text style={styles.greeting}>{getTimeOfDay()},</Text>
          <Text style={styles.name}>{username}</Text>
          <Text style={styles.message}>{greeting}</Text>
        </View>
        <Image
          source={{ uri: 'https://images.pexels.com/photos/1716861/pexels-photo-1716861.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260' }}
          style={styles.image}
        />
      </View>
    </Card>
  );
}

const styles = StyleSheet.create({
  container: {
    marginVertical: 16,
    borderRadius: 20,
    padding: 0,
    overflow: 'hidden',
  },
  content: {
    flexDirection: 'row',
    alignItems: 'center',
    overflow: 'hidden',
  },
  textContainer: {
    flex: 1,
    padding: 20,
  },
  greeting: {
    fontFamily: 'Inter-Medium',
    fontSize: 16,
    color: '#4B5563',
    marginBottom: 4,
  },
  name: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 24,
    color: '#333333',
    marginBottom: 8,
  },
  message: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#6B7280',
    lineHeight: 20,
  },
  image: {
    width: 100,
    height: '100%',
    resizeMode: 'cover',
  },
});