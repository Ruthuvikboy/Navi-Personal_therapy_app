import React from 'react';
import { StyleSheet, View, Text } from 'react-native';

interface MessageBubbleProps {
  message: string;
  isUser: boolean;
  timestamp?: string;
}

export default function MessageBubble({
  message,
  isUser,
  timestamp,
}: MessageBubbleProps) {
  return (
    <View style={[
      styles.container,
      isUser ? styles.userContainer : styles.botContainer
    ]}>
      <View
        style={[
          styles.bubble,
          isUser ? styles.userBubble : styles.botBubble
        ]}
      >
        <Text style={[
          styles.message,
          isUser ? styles.userMessage : styles.botMessage
        ]}>
          {message}
        </Text>
      </View>
      {timestamp && (
        <Text style={styles.timestamp}>{timestamp}</Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    maxWidth: '80%',
    marginVertical: 4,
  },
  userContainer: {
    alignSelf: 'flex-end',
  },
  botContainer: {
    alignSelf: 'flex-start',
  },
  bubble: {
    borderRadius: 16,
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  userBubble: {
    backgroundColor: '#4A90E2',
    borderBottomRightRadius: 4,
  },
  botBubble: {
    backgroundColor: '#F3F4F6',
    borderBottomLeftRadius: 4,
  },
  message: {
    fontSize: 14,
    lineHeight: 20,
  },
  userMessage: {
    color: '#FFFFFF',
    fontFamily: 'Inter-Regular',
  },
  botMessage: {
    color: '#333333',
    fontFamily: 'Inter-Regular',
  },
  timestamp: {
    fontSize: 10,
    color: '#9E9E9E',
    marginTop: 4,
    fontFamily: 'Inter-Regular',
    alignSelf: 'flex-end',
  },
});