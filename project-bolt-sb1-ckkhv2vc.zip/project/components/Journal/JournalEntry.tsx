import React from 'react';
import { StyleSheet, View, Text, TouchableOpacity } from 'react-native';
import { CreditCard as Edit2 } from 'lucide-react-native';
import Card from '../ui/Card';

interface JournalEntryProps {
  date: string;
  title: string;
  snippet: string;
  mood?: string;
  onPress?: () => void;
}

export default function JournalEntry({
  date,
  title,
  snippet,
  mood,
  onPress,
}: JournalEntryProps) {
  // Format the date
  const formattedDate = new Date(date).toLocaleDateString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
  });

  return (
    <TouchableOpacity onPress={onPress} activeOpacity={0.8}>
      <Card variant="elevated" style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.date}>{formattedDate}</Text>
          {mood && (
            <View style={styles.moodContainer}>
              <Text style={styles.mood}>{mood}</Text>
            </View>
          )}
        </View>
        <Text style={styles.title}>{title}</Text>
        <Text style={styles.snippet} numberOfLines={3}>
          {snippet}
        </Text>
        <View style={styles.footer}>
          <TouchableOpacity 
            style={styles.editButton} 
            onPress={onPress}
            activeOpacity={0.6}
          >
            <Edit2 size={16} color="#4A90E2" />
            <Text style={styles.editText}>Edit</Text>
          </TouchableOpacity>
        </View>
      </Card>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    marginVertical: 8,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  date: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
    color: '#666666',
  },
  moodContainer: {
    paddingHorizontal: 8,
    paddingVertical: 2,
    backgroundColor: '#F3F4F6',
    borderRadius: 8,
  },
  mood: {
    fontFamily: 'Inter-Medium',
    fontSize: 12,
    color: '#4B5563',
  },
  title: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 18,
    marginBottom: 8,
    color: '#333333',
  },
  snippet: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    lineHeight: 20,
    color: '#4B5563',
    marginBottom: 12,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    borderTopWidth: 1,
    borderTopColor: '#F3F4F6',
    paddingTop: 8,
    marginTop: 4,
  },
  editButton: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 4,
  },
  editText: {
    fontFamily: 'Inter-Medium',
    fontSize: 12,
    color: '#4A90E2',
    marginLeft: 4,
  },
});