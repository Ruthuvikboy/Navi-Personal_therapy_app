import React from 'react';
import { StyleSheet, View, Text, ScrollView } from 'react-native';
import Card from '../ui/Card';

type Mood = 'great' | 'good' | 'okay' | 'sad' | 'awful';

interface MoodEntry {
  date: string;
  mood: Mood;
  note?: string;
}

interface MoodCalendarProps {
  entries: MoodEntry[];
  month: string;
}

const moodColors = {
  great: '#4CAF50',
  good: '#8BC34A',
  okay: '#FFC107',
  sad: '#FF9800',
  awful: '#F44336',
};

const moodEmojis = {
  great: '😄',
  good: '🙂',
  okay: '😐',
  sad: '😔',
  awful: '😢',
};

export default function MoodCalendar({
  entries,
  month,
}: MoodCalendarProps) {
  // Group entries by week for display
  const weeks = groupEntriesByWeek(entries);

  return (
    <Card variant="outlined" style={styles.container}>
      <Text style={styles.monthTitle}>{month}</Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false}>
        {weeks.map((week, weekIndex) => (
          <View key={`week-${weekIndex}`} style={styles.week}>
            {week.map((entry, dayIndex) => (
              <View 
                key={`day-${weekIndex}-${dayIndex}`} 
                style={styles.dayContainer}
              >
                <Text style={styles.dayNumber}>
                  {entry ? new Date(entry.date).getDate() : ' '}
                </Text>
                {entry && (
                  <View 
                    style={[
                      styles.moodIndicator, 
                      { backgroundColor: moodColors[entry.mood] }
                    ]}
                  >
                    <Text>{moodEmojis[entry.mood]}</Text>
                  </View>
                )}
              </View>
            ))}
          </View>
        ))}
      </ScrollView>
    </Card>
  );
}

// Helper function to group entries by week
function groupEntriesByWeek(entries: MoodEntry[]): (MoodEntry | null)[][] {
  // Sort entries by date
  const sortedEntries = [...entries].sort(
    (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()
  );

  if (sortedEntries.length === 0) return [];

  // Create a map of date -> entry for easier lookup
  const entryMap = new Map<string, MoodEntry>();
  sortedEntries.forEach(entry => {
    entryMap.set(entry.date, entry);
  });

  // Get first and last dates
  const firstDate = new Date(sortedEntries[0].date);
  const lastDate = new Date(sortedEntries[sortedEntries.length - 1].date);

  // Make first date start at the beginning of its week (Sunday)
  const startDay = firstDate.getDay();
  firstDate.setDate(firstDate.getDate() - startDay);

  // Make last date end at the end of its week (Saturday)
  const endDay = lastDate.getDay();
  lastDate.setDate(lastDate.getDate() + (6 - endDay));

  // Create weeks array
  const weeks: (MoodEntry | null)[][] = [];
  let currentWeek: (MoodEntry | null)[] = [];
  
  const currentDate = new Date(firstDate);
  while (currentDate <= lastDate) {
    const dateString = currentDate.toISOString().split('T')[0];
    const entry = entryMap.get(dateString) || null;
    
    currentWeek.push(entry);
    
    if (currentWeek.length === 7) {
      weeks.push(currentWeek);
      currentWeek = [];
    }
    
    currentDate.setDate(currentDate.getDate() + 1);
  }
  
  // Add the last partial week if it exists
  if (currentWeek.length > 0) {
    while (currentWeek.length < 7) {
      currentWeek.push(null);
    }
    weeks.push(currentWeek);
  }
  
  return weeks;
}

const styles = StyleSheet.create({
  container: {
    padding: 16,
    marginBottom: 16,
  },
  monthTitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    marginBottom: 12,
    color: '#333333',
  },
  week: {
    flexDirection: 'row',
    marginBottom: 8,
  },
  dayContainer: {
    width: 40,
    height: 60,
    alignItems: 'center',
    justifyContent: 'flex-start',
    marginHorizontal: 4,
  },
  dayNumber: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
    color: '#666666',
    marginBottom: 4,
  },
  moodIndicator: {
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
});