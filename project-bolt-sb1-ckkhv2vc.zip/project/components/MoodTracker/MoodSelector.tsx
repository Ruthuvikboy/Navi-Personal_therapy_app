import React from 'react';
import { StyleSheet, View, Text, TouchableOpacity, Animated } from 'react-native';

type Mood = 'great' | 'good' | 'okay' | 'sad' | 'awful';

interface MoodSelectorProps {
  selectedMood: Mood | null;
  onSelectMood: (mood: Mood) => void;
}

const moods: { value: Mood; emoji: string; label: string; color: string }[] = [
  { value: 'great', emoji: '😄', label: 'Great', color: '#4CAF50' },
  { value: 'good', emoji: '🙂', label: 'Good', color: '#8BC34A' },
  { value: 'okay', emoji: '😐', label: 'Okay', color: '#FFC107' },
  { value: 'sad', emoji: '😔', label: 'Sad', color: '#FF9800' },
  { value: 'awful', emoji: '😢', label: 'Awful', color: '#F44336' },
];

export default function MoodSelector({
  selectedMood,
  onSelectMood,
}: MoodSelectorProps) {
  return (
    <View style={styles.container}>
      <Text style={styles.question}>How are you feeling today?</Text>
      <View style={styles.moodsContainer}>
        {moods.map((mood) => (
          <TouchableOpacity
            key={mood.value}
            style={[
              styles.moodButton,
              selectedMood === mood.value && styles.selectedMoodButton,
              { borderColor: mood.color },
            ]}
            onPress={() => onSelectMood(mood.value)}
            activeOpacity={0.7}
          >
            <Text style={styles.emoji}>{mood.emoji}</Text>
            <Text
              style={[
                styles.moodLabel,
                selectedMood === mood.value && styles.selectedMoodLabel,
                { color: selectedMood === mood.value ? mood.color : '#666666' },
              ]}
            >
              {mood.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginVertical: 16,
  },
  question: {
    fontFamily: 'Inter-Medium',
    fontSize: 18,
    marginBottom: 16,
    textAlign: 'center',
    color: '#333333',
  },
  moodsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 8,
  },
  moodButton: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 12,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: 'transparent',
    backgroundColor: '#F5F5F5',
    width: 64,
    aspectRatio: 1,
  },
  selectedMoodButton: {
    backgroundColor: '#FFFFFF',
    transform: [{ scale: 1.05 }],
  },
  emoji: {
    fontSize: 28,
    marginBottom: 4,
  },
  moodLabel: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
    color: '#666666',
  },
  selectedMoodLabel: {
    fontFamily: 'Inter-Medium',
  },
});