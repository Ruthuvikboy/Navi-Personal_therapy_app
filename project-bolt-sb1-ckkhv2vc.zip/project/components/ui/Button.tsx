import React from 'react';
import { 
  StyleSheet, 
  Text, 
  TouchableOpacity, 
  ViewStyle, 
  TextStyle, 
  ActivityIndicator,
  Platform
} from 'react-native';
import { useNavigation } from 'expo-router';

interface ButtonProps {
  title: string;
  onPress?: () => void;
  href?: string;
  variant?: 'primary' | 'secondary' | 'outline' | 'text';
  size?: 'small' | 'medium' | 'large';
  fullWidth?: boolean;
  style?: ViewStyle;
  textStyle?: TextStyle;
  disabled?: boolean;
  loading?: boolean;
  icon?: React.ReactNode;
}

export default function Button({
  title,
  onPress,
  href,
  variant = 'primary',
  size = 'medium',
  fullWidth = false,
  style,
  textStyle,
  disabled = false,
  loading = false,
  icon,
}: ButtonProps) {
  const navigation = useNavigation();

  const handlePress = () => {
    if (disabled || loading) return;
    
    if (href) {
      navigation.navigate(href as never);
    } else if (onPress) {
      onPress();
    }
  };

  const getButtonStyle = () => {
    let buttonStyle: ViewStyle[] = [styles.button];

    // Add variant style
    switch (variant) {
      case 'primary':
        buttonStyle.push(styles.primaryButton);
        break;
      case 'secondary':
        buttonStyle.push(styles.secondaryButton);
        break;
      case 'outline':
        buttonStyle.push(styles.outlineButton);
        break;
      case 'text':
        buttonStyle.push(styles.textButton);
        break;
    }

    // Add size style
    switch (size) {
      case 'small':
        buttonStyle.push(styles.smallButton);
        break;
      case 'medium':
        buttonStyle.push(styles.mediumButton);
        break;
      case 'large':
        buttonStyle.push(styles.largeButton);
        break;
    }

    // Add fullWidth style
    if (fullWidth) {
      buttonStyle.push(styles.fullWidth);
    }

    // Add disabled style
    if (disabled) {
      buttonStyle.push(styles.disabledButton);
    }

    return buttonStyle;
  };

  const getTextStyle = () => {
    let textStyleArray: TextStyle[] = [styles.text];

    // Add variant text style
    switch (variant) {
      case 'primary':
        textStyleArray.push(styles.primaryText);
        break;
      case 'secondary':
        textStyleArray.push(styles.secondaryText);
        break;
      case 'outline':
        textStyleArray.push(styles.outlineText);
        break;
      case 'text':
        textStyleArray.push(styles.textText);
        break;
    }

    // Add size text style
    switch (size) {
      case 'small':
        textStyleArray.push(styles.smallText);
        break;
      case 'medium':
        textStyleArray.push(styles.mediumText);
        break;
      case 'large':
        textStyleArray.push(styles.largeText);
        break;
    }

    // Add disabled text style
    if (disabled) {
      textStyleArray.push(styles.disabledText);
    }

    return textStyleArray;
  };

  return (
    <TouchableOpacity
      onPress={handlePress}
      style={[...getButtonStyle(), style]}
      disabled={disabled || loading}
      activeOpacity={0.8}
    >
      {loading ? (
        <ActivityIndicator 
          size="small" 
          color={variant === 'outline' || variant === 'text' ? '#4A90E2' : '#FFFFFF'} 
        />
      ) : (
        <>
          {icon && icon}
          <Text style={[...getTextStyle(), textStyle, icon ? styles.textWithIcon : {}]}>
            {title}
          </Text>
        </>
      )}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  button: {
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'row',
  },
  primaryButton: {
    backgroundColor: '#4A90E2',
    shadowColor: '#4A90E2',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 2,
  },
  secondaryButton: {
    backgroundColor: '#9C6ADE',
  },
  outlineButton: {
    backgroundColor: 'transparent',
    borderWidth: 1,
    borderColor: '#4A90E2',
  },
  textButton: {
    backgroundColor: 'transparent',
  },
  smallButton: {
    paddingVertical: 8,
    paddingHorizontal: 16,
    minWidth: 80,
  },
  mediumButton: {
    paddingVertical: 12,
    paddingHorizontal: 24,
    minWidth: 120,
  },
  largeButton: {
    paddingVertical: 16,
    paddingHorizontal: 32,
    minWidth: 160,
  },
  fullWidth: {
    width: '100%',
  },
  disabledButton: {
    backgroundColor: '#E1E1E1',
    borderColor: '#E1E1E1',
    shadowOpacity: 0,
    elevation: 0,
  },
  text: {
    fontFamily: 'Inter-Medium',
    textAlign: 'center',
  },
  primaryText: {
    color: '#FFFFFF',
  },
  secondaryText: {
    color: '#FFFFFF',
  },
  outlineText: {
    color: '#4A90E2',
  },
  textText: {
    color: '#4A90E2',
  },
  smallText: {
    fontSize: 12,
  },
  mediumText: {
    fontSize: 14,
  },
  largeText: {
    fontSize: 16,
  },
  disabledText: {
    color: '#9E9E9E',
  },
  textWithIcon: {
    marginLeft: 8,
  },
});