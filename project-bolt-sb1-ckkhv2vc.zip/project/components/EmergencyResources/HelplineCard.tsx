import React from 'react';
import { StyleSheet, View, Text, TouchableOpacity, Platform, Linking } from 'react-native';
import { Phone } from 'lucide-react-native';
import Card from '../ui/Card';

interface HelplineCardProps {
  title: string;
  number: string;
  description: string;
  color: string;
}

export default function HelplineCard({
  title,
  number,
  description,
  color,
}: HelplineCardProps) {
  const handleCall = () => {
    const phoneNumber = Platform.OS === 'ios' ? `tel:${number}` : `tel:${number}`;
    Linking.canOpenURL(phoneNumber)
      .then(supported => {
        if (supported) {
          Linking.openURL(phoneNumber);
        } else {
          console.log("Phone call not supported");
        }
      })
      .catch(err => console.error('An error occurred', err));
  };

  return (
    <Card variant="elevated" style={styles.container}>
      <View style={styles.header}>
        <View style={[styles.iconContainer, { backgroundColor: color }]}>
          <Phone size={20} color="#FFFFFF" />
        </View>
        <View style={styles.titleContainer}>
          <Text style={styles.title}>{title}</Text>
          <Text style={styles.number}>{number}</Text>
        </View>
      </View>
      <Text style={styles.description}>{description}</Text>
      <TouchableOpacity
        style={[styles.callButton, { backgroundColor: color }]}
        onPress={handleCall}
        activeOpacity={0.8}
      >
        <Phone size={16} color="#FFFFFF" />
        <Text style={styles.callButtonText}>Call Now</Text>
      </TouchableOpacity>
    </Card>
  );
}

const styles = StyleSheet.create({
  container: {
    marginVertical: 8,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  iconContainer: {
    width: 40,
    height: 40,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  titleContainer: {
    flex: 1,
  },
  title: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    color: '#333333',
  },
  number: {
    fontFamily: 'Inter-Medium',
    fontSize: 14,
    color: '#4B5563',
  },
  description: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#4B5563',
    marginBottom: 16,
    lineHeight: 20,
  },
  callButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    borderRadius: 8,
  },
  callButtonText: {
    fontFamily: 'Inter-Medium',
    fontSize: 14,
    color: '#FFFFFF',
    marginLeft: 8,
  },
});